<?php 

Class User 
{

	function login($POST)
	{
		$DB = new Database();
		
		$_SESSION['error'] = "";
		if(isset($POST['useremail']) && isset($POST['password']))
		{
			$arr['useremail'] = $POST['useremail'];
			$pass = $_POST['password'];

			$query = "SELECT email, password from user where email = :useremail limit 1";
			$data = $DB->read($query,$arr);
			if(is_array($data))
			{

 				//logged in
 				$_SESSION['user_name'] = $data[0]->useremail;
				$password = $data[0]->password;
				 if(password_verify($pass, $password)){
				
				header("Location:". ROOT . "home");
				
				 }

			}else{
				$_SESSION['error'] = "wrong username or password";
			}
		}else{

			$_SESSION['error'] = "please enter a valid username and password";
		}

	}

	function signup($POST)
	{

		$DB = new Database();


		$_SESSION['error'] = "";
		if(isset($POST['email']) && isset($POST['password']))
		{
			if(isset($_POST['name'])){
				if(preg_match("/^[a-z,A-Z, ]*$/", $POST['name'])){
					$arr['name'] = $POST['name'];
				}else{
					echo "Please enter valid name";
				}
			}
//			$arr['name'] = $POST['name'];
			$arr['email'] = $POST['email'];

			$arr['password'] = password_hash($POST['password'], PASSWORD_BCRYPT);
//			$arr['password'] = $POST['password'];

			if(isset($_POST['mobile'])){
				if(strlen($POST['mobile']) == 10){
					if(preg_match("/^[0-9]+$/", $POST['mobile'])){
						$arr['mobile'] = $POST['mobile'];
					}
				}
			}
//			$arr['mobile'] = $POST['mobile'];
			$arr['address'] = $POST['address'];

			if(isset($_POST['city'])){
				if(preg_match("/^[a-z,A-Z, ]*$/", $POST['city'])){
					$arr['city'] = $POST['city'];
				}else{
					echo "Please enter correct city name";
				}
			}
//			$arr['city'] = $POST['city'];

			if(isset($_POST['state'])){
				if(preg_match("/^[a-z,A-Z, ]*$/", $POST['state'])){
					$arr['state'] = $POST['state'];
				}else{
					echo "Please enter valid state";
				}
			}
			//$arr['state'] = $POST['state'];
			
			if(isset($_POST['country'])){
				if(preg_match("/^[a-z,A-Z, ]*$/", $POST['country'])){
					$arr['country'] = $POST['country'];
				}else{
					echo "Please enter valid country";
				}
			}
//			$arr['country'] = $POST['country'];

			if(isset($_POST['zip'])){
				if(strlen($POST['zip']) == 6){
					if(preg_match("/^[0-9]+$/", $POST['zip'])){
						$arr['zip'] = $POST['zip'];
					}
				}
			}
//			$arr['zip'] = $POST['zip'];

			$query = "INSERT into user (name, email, password, mobile, address, city, state, country, zip) values (:name, :email, :password, :mobile, :address, :city, :state, :country, :zip)";
			$data = $DB->write($query,$arr);
			if($data)
			{
				
				header("Location:". ROOT . "login");
				die;
			}

		}else{

			$_SESSION['error'] = "please enter a valid username and password";
		}
	}

	function check_logged_in()
	{

		$DB = new Database();
		if(isset($_SESSION['user_name']))
		{
			header("Location:". ROOT . "home");
		}

		return false;

	}

	function logout()
	{
		//logged in
		unset($_SESSION['user_name']);
//		unset($_SESSION['user_url']);

		header("Location:". ROOT . "login");
		die;
	}

	function show()
	{
		if(isset($_SESSION['user_name']))
		{
			$DB = new Database();
		
			$_SESSION['error'] = "";
			if(isset($POST['useremail']) && isset($POST['password']))
			{
				$arr['useremail'] = $POST['useremail'];
				$pass = $_POST['password'];

				$query = "SELECT * from user where email = :useremail limit 1";
				$data = $DB->read($query,$arr);
				if(is_array($data))
				{
					return $this->$data;
				}
						
		}
	}
	}
}