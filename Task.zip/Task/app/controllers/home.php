<?php

Class Home extends Controller 
{
	function index()
	{
 	 	
 	 	$data['page_title'] = "Home";

 	 	if(isset($_SESSION['user_name']))
 	 	{
 	 		$user = $this->loadModel("user");
 	 		$user->show($_POST);

 	 	}

		$this->view("minima/home",$data);
	}

}