<?php $this->view("minima/header",$data);?>

<?php

echo $this->data[0];
?>